package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;

@SpringBootApplication
public class CollectionApplication {
	
	private static final String MEETUP_RSVPS_ENDPOINT = "ws://stream.meetup.com/2/rsvps";

	public static void main(String[] args) {
		SpringApplication.run(CollectionApplication.class, args);
	}
	
	//Application Runner executes 
	@Bean
	public ApplicationRunner initializeConnection(RsvpsWebSocketHandler rsvpsWebSockhandler) {
		return args -> {
			WebSocketClient rsvpsWebSclient = new StandardWebSocketClient();
			
			rsvpsWebSclient.doHandshake(rsvpsWebSockhandler, MEETUP_RSVPS_ENDPOINT);
		};
		
	}

}
